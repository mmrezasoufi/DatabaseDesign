# Academic staff management system

A back-end for managing academic staff in a university

## Diagram
[Digram in GoogleDrive](https://drive.google.com/file/d/1d3I85F1LHfmMR3n_x4SvY4TFgrGqdP1a/view?usp=sharing)

## Features
1. An API over all entities for CRUD
2. Add authentication for create, update and delete accesses

## Deployment